from deriv import deriv
from deriv import gauss

